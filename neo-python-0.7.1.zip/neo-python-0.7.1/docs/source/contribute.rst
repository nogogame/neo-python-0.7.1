Contribute
==========


Help
----

-  Open a new `issue`_ if you encounter a problem.
-  Or ping **@localhuman** or **@metachris** on the `NEO Discord`_.
-  Pull requests are welcome. New features, writing tests and
   documentation are all needed.
   

Donations
---------

Accepted at Neo address **ATEMNPSjRVvsXmaJW4ZYJBSVuJ6uR2mjQU**.

.. _issue: https://github.com/CityOfZion/neo-python/issues/new
.. _NEO Discord: https://discord.gg/R8v48YA
