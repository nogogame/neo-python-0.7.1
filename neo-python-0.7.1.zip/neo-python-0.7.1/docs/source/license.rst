License
-------

-  Open-source `MIT`_.
-  Contributors: [@localhuman](https://github.com/localhuman) (Creator), [@metachris](https://github.com/metachris), [@ixje](https://github.com/ixje), and [many more](https://github.com/CityOfZion/neo-python/graphs/contributors)

.. _MIT: https://github.com/CityOfZion/neo-python/blob/master/LICENSE.md
